import{b as a}from"../chunks/entry.CB1J30oF.js";export{a as start};
