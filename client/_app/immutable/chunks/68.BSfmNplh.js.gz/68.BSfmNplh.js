const r=""+new URL("../assets/68.CdPm6NzO.jpg",import.meta.url).href;export{r};
